const API_BASE =
  window.API_BASE_URL ||
  (window.location.port === '3000'
    ? ''
    : `${window.location.protocol}//${window.location.hostname}:3000`);

function apiFetch(path, options = {}) {
  const url = `${API_BASE}${path}`;
  return fetch(url, options);
}

const state = {
  dashboard: null,
  doctorDashboard: null,
  activePetId: null,
  currentUser: null,
  selectedConsultationId: null,
  selectedPatientId: null,
};

async function loadDashboard() {
  if (!state.currentUser || !state.currentUser.id) {
    throw new Error('未登录');
  }
  const res = await apiFetch(`/api/dashboard?userId=${encodeURIComponent(state.currentUser.id)}`);
  if (!res.ok) {
    throw new Error('加载数据失败');
  }
  state.dashboard = await res.json();
  if (!state.activePetId && state.dashboard.pets.length) {
    state.activePetId = state.dashboard.pets[0].id;
  }
  const nameEl = document.querySelector('#user-name');
  if (nameEl && state.dashboard?.currentUser?.name) {
    nameEl.textContent = state.dashboard.currentUser.name;
  }
  renderUserDashboard();
}

async function loadDoctorDashboard() {
  if (!state.currentUser || !state.currentUser.id) {
    throw new Error('未登录');
  }
  const res = await apiFetch(`/api/doctor-dashboard?doctorId=${encodeURIComponent(state.currentUser.id)}`);
  if (!res.ok) {
    throw new Error('加载数据失败');
  }
  state.doctorDashboard = await res.json();
  const nameEl = document.querySelector('#user-name');
  if (nameEl && state.doctorDashboard?.doctor?.name) {
    nameEl.textContent = state.doctorDashboard.doctor.name;
  }
  renderDoctorDashboard();
}

function renderUserDashboard() {
  renderPetList();
  renderPetProfile();
  renderWeightChart();
  renderLogs();
  renderReminders();
  renderAlerts();
  renderConsultations();
  fillConsultFormOptions();
}

function renderDoctorDashboard() {
  renderDoctorConsultations();
  renderDoctorPatients();
}

function renderPetList() {
  const list = document.querySelector('#pet-list');
  if (!list) return;
  list.innerHTML = '';
  if (!state.dashboard || !state.dashboard.pets.length) {
    list.innerHTML = '<p>暂无宠物档案</p>';
    return;
  }
  state.dashboard.pets.forEach((pet) => {
    const card = document.createElement('div');
    card.className = 'pet-card';
    card.dataset.id = pet.id;
    if (pet.id === state.activePetId) {
      card.classList.add('active');
    }
    const initials = pet.name ? pet.name.slice(0, 1) : '宠';
    const avatarColor = pet.avatarColor || '#6366f1';
    card.innerHTML = `
      <div class="pet-avatar" style="background:${avatarColor};">${initials}</div>
      <div class="pet-card-info">
        <strong>${pet.name}</strong>
        <div class="pet-card-meta">${pet.species || '未知物种'} · ${pet.breed || '品种未填写'}</div>
        <div class="pet-card-meta">年龄：${pet.age ? `${pet.age} 岁` : '未知'} · 医疗档案 ${pet.medicalRecords?.length || 0} 条</div>
      </div>
    `;
    list.appendChild(card);
  });
}

function renderPetProfile() {
  const profile = document.querySelector('#pet-profile');
  if (!profile) return;
  const pet = state.dashboard.pets.find((p) => p.id === state.activePetId);
  if (!pet) {
    profile.innerHTML = '<p>暂无宠物档案</p>';
    return;
  }
  const nextVacc = pet.vaccinations?.[0]?.nextDue ? new Date(pet.vaccinations[0].nextDue).toLocaleDateString() : '未设置';
  profile.innerHTML = `
    <h3>${pet.name}</h3>
    <p>品种：${pet.species} / ${pet.breed || '未知'}</p>
    <p>年龄：${pet.age || '未知'} 岁</p>
    <p>最近疫苗：${pet.vaccinations?.[0]?.name || '暂无'}，下次：${nextVacc}</p>
    <p>医疗档案：${pet.medicalRecords?.length || 0} 条</p>
  `;
}

function renderWeightChart() {
  const canvas = document.querySelector('#weight-chart');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const pet = state.dashboard.pets.find((p) => p.id === state.activePetId);
  if (!pet || !pet.weightSeries.length) {
    ctx.fillStyle = '#64748b';
    ctx.font = '16px sans-serif';
    ctx.fillText('暂无体重数据', 20, canvas.height / 2);
    return;
  }
  const padding = 40;
  const width = canvas.width - padding * 2;
  const height = canvas.height - padding * 2;
  const weights = pet.weightSeries.map((point) => point.weight);
  const minWeight = Math.min(...weights) - 0.1;
  const maxWeight = Math.max(...weights) + 0.1;

  // axes
  ctx.strokeStyle = '#cbd5f5';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(padding, padding);
  ctx.lineTo(padding, canvas.height - padding);
  ctx.lineTo(canvas.width - padding / 2, canvas.height - padding);
  ctx.stroke();

  ctx.fillStyle = '#475569';
  ctx.font = '12px sans-serif';
  ctx.fillText(`${maxWeight.toFixed(1)} kg`, 5, padding - 8);
  ctx.fillText(`${minWeight.toFixed(1)} kg`, 5, canvas.height - padding + 15);

  ctx.strokeStyle = '#2563eb';
  ctx.lineWidth = 2;
  ctx.beginPath();
  pet.weightSeries.forEach((point, index) => {
    const x = padding + (width * index) / (pet.weightSeries.length - 1 || 1);
    const yRatio = (point.weight - minWeight) / (maxWeight - minWeight || 1);
    const y = canvas.height - padding - yRatio * height;
    if (index === 0) {
      ctx.moveTo(x, y);
    } else {
      ctx.lineTo(x, y);
    }
  });
  ctx.stroke();

  ctx.fillStyle = '#475569';
  ctx.font = '11px sans-serif';
  pet.weightSeries.forEach((point, index) => {
    const x = padding + (width * index) / (pet.weightSeries.length - 1 || 1);
    const yRatio = (point.weight - minWeight) / (maxWeight - minWeight || 1);
    const y = canvas.height - padding - yRatio * height;
    ctx.fillText(point.date, x - 30, canvas.height - padding + 25);
  });
}

function renderLogs() {
  const tbody = document.querySelector('#log-table tbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  const pet = state.dashboard.pets.find((p) => p.id === state.activePetId);
  if (!pet) return;
  const logsData = (state.dashboard.healthLogs || []).filter((log) => log.petId === pet.id);
  if (!logsData.length) {
    const row = document.createElement('tr');
    row.innerHTML = '<td colspan=\"4\">暂无健康记录</td>';
    tbody.appendChild(row);
    return;
  }
  logsData
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .forEach((log) => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${log.date}</td>
        <td>${log.weight}</td>
        <td>${log.diet}</td>
        <td>${log.exercise}</td>
      `;
      tbody.appendChild(row);
    });
}

function renderReminders() {
  const list = document.querySelector('#reminder-list');
  if (!list) return;
  list.innerHTML = '';
  state.dashboard.reminders
    .filter((item) => item.pet && item.pet.id === state.activePetId)
    .sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate))
    .forEach((reminder) => {
      const li = document.createElement('li');
      const dueDate = reminder.dueDate ? new Date(reminder.dueDate).toLocaleDateString() : '未设置';
      li.innerHTML = `
        <div>
          <strong>${reminder.title}</strong>
          <span class="tag ${reminder.completed ? 'success' : 'warning'}">
            ${reminder.completed ? '已完成' : '待处理'}
          </span>
        </div>
        <span>到期时间：${dueDate}</span>
        <button data-id="${reminder.id}" class="reminder-action" ${reminder.completed ? 'disabled' : ''}>标记完成</button>
      `;
      list.appendChild(li);
    });
}

function renderAlerts() {
  const list = document.querySelector('#alert-list');
  if (!list) return;
  list.innerHTML = '';
  state.dashboard.alerts
    .filter((alert) => alert.pet && alert.pet.id === state.activePetId)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .forEach((alert) => {
      const li = document.createElement('li');
      const time = alert.createdAt ? new Date(alert.createdAt).toLocaleString() : '未知时间';
      li.innerHTML = `
        <div>
          <strong>${alert.message}</strong>
        </div>
        <span class="tag danger">${alert.type}</span>
        <span>时间：${time}</span>
      `;
      list.appendChild(li);
    });
}

function renderConsultations() {
  const container = document.querySelector('#consultation-list');
  if (!container) return;
  container.innerHTML = '';
  const items = state.dashboard.consultations
    .filter((c) => c.pet && c.pet.id === state.activePetId)
    .sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
  if (!items.length) {
    container.innerHTML = '<p>暂无在线咨询记录</p>';
    return;
  }
  items.forEach((consult) => {
      const card = document.createElement('div');
      card.className = 'consultation-card';
      const createdAt = consult.createdAt ? new Date(consult.createdAt).toLocaleString() : '未知';
      card.innerHTML = `
        <div class="consultation-meta">
          <span>医生：${consult.doctor?.name || '待分配'}</span>
          <span>发起时间：${createdAt}</span>
        </div>
        <p>问题：${consult.question}</p>
        <div class="status-badge ${consult.status}">状态：${translateStatus(consult.status)}</div>
        ${consult.doctorNotes ? `<p>医生建议：${consult.doctorNotes}</p>` : ''}
        ${consult.prescriptionId ? `<p>处方编号：${consult.prescriptionId}</p>` : ''}
      `;
      container.appendChild(card);
    });
}

function translateStatus(status) {
  switch (status) {
    case 'in_review':
      return '待医生回复';
    case 'answered':
      return '医生已回复';
    case 'pending_review':
      return '处方待审核';
    default:
      return status;
  }
}

function renderDoctorConsultations() {
  const container = document.querySelector('#doctor-consultations');
  if (!container) return;
  container.innerHTML = '';
  const dashboard = state.doctorDashboard;
  if (!dashboard || !dashboard.consultations.length) {
    container.innerHTML = '<p>暂无在线咨询</p>';
    return;
  }
  dashboard.consultations.forEach((consult) => {
    const card = document.createElement('div');
    card.className = 'consultation-card doctor';
    card.dataset.id = consult.id;
    const createdAt = consult.createdAt ? new Date(consult.createdAt).toLocaleString() : '未知';
    const userName = consult.user?.name || '未知用户';
    const petName = consult.pet?.name || '未知宠物';
    const latestHealth = consult.pet?.latestHealth
      ? `最近一次记录：${consult.pet.latestHealth.date} · 体重 ${consult.pet.latestHealth.weight}kg`
      : '暂无近期健康记录';
    card.innerHTML = `
      <div class="consultation-meta">
        <span>用户：${userName}</span>
        <span>宠物：${petName}</span>
        <span>发起时间：${createdAt}</span>
      </div>
      <p>问题：${consult.question}</p>
      <p class="latest-health">${latestHealth}</p>
      <div class="status-badge ${consult.status}">状态：${translateStatus(consult.status)}</div>
      ${
        consult.doctorNotes
          ? `<p>已有回复：${consult.doctorNotes}</p>`
          : '<p class="pending-reply">尚未回复，请及时处理。</p>'
      }
      <div class="doctor-actions">
        <button type="button" class="secondary" data-action="view-patient" data-user-id="${consult.user?.id || ''}" ${
      consult.user?.id ? '' : 'disabled'
    }>查看用户</button>
        <button type="button" data-action="respond" data-id="${consult.id}">回复咨询</button>
      </div>
    `;
    container.appendChild(card);
  });
}

function renderDoctorPatients() {
  const container = document.querySelector('#doctor-patients');
  if (!container) return;
  container.innerHTML = '';
  const dashboard = state.doctorDashboard;
  if (!dashboard || !dashboard.patients.length) {
    container.innerHTML = '<p>暂无关联用户</p>';
    return;
  }
  dashboard.patients.forEach((patient) => {
    const card = document.createElement('div');
    card.className = 'patient-card';
    card.dataset.userId = patient.id;
    const petSummary = patient.pets
      .map((pet) => `${pet.name}（${pet.species}）`)
      .join('、');
    card.innerHTML = `
      <div class="patient-header">
        <strong>${patient.name}</strong>
        <span>${patient.email || ''}</span>
      </div>
      <p>宠物：${petSummary || '暂无宠物数据'}</p>
      <button type="button" class="secondary" data-action="view-detail" data-user-id="${patient.id}">查看详情</button>
    `;
    container.appendChild(card);
  });
}

function populateConsultResponseModal(consultId) {
  const consult = state.doctorDashboard?.consultations.find((c) => c.id === consultId);
  const titleEl = document.getElementById('consult-response-title');
  const questionEl = document.getElementById('consult-response-question');
  const statusSelect = document.querySelector('#consult-response-form select[name="status"]');
  const notesField = document.querySelector('#consult-response-form textarea[name="doctorNotes"]');
  const prescriptionItems = document.querySelector('#consult-response-form textarea[name="prescriptionItems"]');
  const prescriptionNotes = document.querySelector('#consult-response-form textarea[name="prescriptionNotes"]');
  if (!consult || !titleEl || !questionEl || !statusSelect || !notesField || !prescriptionItems || !prescriptionNotes) {
    return;
  }
  titleEl.textContent = `回复咨询：${consult.user?.name || '未知用户'} / ${consult.pet?.name || '未知宠物'}`;
  questionEl.textContent = consult.question || '无提问内容';
  statusSelect.value = consult.status || 'answered';
  notesField.value = consult.doctorNotes || '';
  prescriptionItems.value = '';
  prescriptionNotes.value = '';
}

function showPatientDetail(userId) {
  const patient = state.doctorDashboard?.patients.find((p) => p.id === userId);
  if (!patient) return;
  state.selectedPatientId = userId;
  const modal = document.getElementById('patient-modal');
  const container = document.getElementById('patient-detail-content');
  if (!modal || !container) return;
  container.innerHTML = `
    <h3>${patient.name}</h3>
    <p>邮箱：${patient.email || '未提供'}</p>
    <div class="patient-pet-list">
      ${
        patient.pets.length
          ? patient.pets
              .map((pet) => {
                const latest = pet.latestHealth
                  ? `最近记录：${pet.latestHealth.date} · 体重 ${pet.latestHealth.weight}kg`
                  : '暂无健康记录';
                const alerts = pet.alerts?.length
                  ? `<ul class="alert-list">${pet.alerts
                      .map((alert) => `<li>${alert.message}（${new Date(alert.createdAt).toLocaleString()}）</li>`)
                      .join('')}</ul>`
                  : '<p>暂无预警</p>';
                return `<div class=\"patient-pet-card\">
                  <strong>${pet.name} · ${pet.species}${pet.breed ? `（${pet.breed}）` : ''}</strong>
                  <p>年龄：${pet.age ?? '未知'} 岁</p>
                  <p>${latest}</p>
                  <div>${alerts}</div>
                </div>`;
              })
              .join('')
          : '<p>用户尚未登记宠物</p>'
      }
    </div>
  `;
  toggleModal('patient-modal', true);
}

function fillConsultFormOptions() {
  const form = document.querySelector('#consult-form');
  if (!form) return;
  const petSelect = form.querySelector('select[name="petId"]');
  const doctorSelect = form.querySelector('select[name="doctorId"]');
  petSelect.innerHTML = '';
  doctorSelect.innerHTML = '';
  state.dashboard.pets.forEach((pet) => {
    const option = document.createElement('option');
    option.value = pet.id;
    option.textContent = pet.name;
    petSelect.appendChild(option);
  });
  state.dashboard.doctors.forEach((doctor) => {
    const option = document.createElement('option');
    option.value = doctor.id;
    option.textContent = `${doctor.name} · ${doctor.specialty || '全科'}`;
    doctorSelect.appendChild(option);
  });
}

function bindUserEvents() {
  const petList = document.querySelector('#pet-list');
  if (petList) {
    petList.addEventListener('click', (event) => {
      const card = event.target.closest('.pet-card');
      if (!card) return;
      const { id } = card.dataset;
      if (!id || id === state.activePetId) {
        return;
      }
      state.activePetId = id;
      renderUserDashboard();
      const activeCard = petList.querySelector(`.pet-card[data-id="${id}"]`);
      if (activeCard && typeof activeCard.scrollIntoView === 'function') {
        activeCard.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
      }
    });
  }

  const openLogButton = document.querySelector('#open-log-modal');
  if (openLogButton) {
    openLogButton.addEventListener('click', () => toggleModal('log-modal', true));
  }

  const openConsultButton = document.querySelector('#open-consult-modal');
  if (openConsultButton) {
    openConsultButton.addEventListener('click', () => toggleModal('consult-modal', true));
  }

  document.querySelectorAll('.modal').forEach((modal) => {
    modal.addEventListener('click', (event) => {
      if (event.target.dataset.action === 'cancel' || event.target === modal) {
        toggleModal(modal.id, false);
      }
    });
  });

  const logForm = document.querySelector('#log-form');
  if (logForm) {
    logForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const petId = state.activePetId;
      const formData = new FormData(event.target);
      const payload = Object.fromEntries(formData.entries());
      payload.weight = Number(payload.weight);
      payload.exercise = Number(payload.exercise);
      try {
        await apiFetch(`/api/pets/${petId}/logs`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        toggleModal('log-modal', false);
        event.target.reset();
        await loadDashboard();
      } catch (error) {
        alert('保存失败，请稍后再试');
      }
    });
  }

  const consultForm = document.querySelector('#consult-form');
  if (consultForm) {
    consultForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const formData = new FormData(event.target);
      const payload = Object.fromEntries(formData.entries());
      payload.userId = state.dashboard.pets.find((p) => p.id === payload.petId)?.ownerId;
      try {
        await apiFetch('/api/consultations', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        toggleModal('consult-modal', false);
        event.target.reset();
        await loadDashboard();
      } catch (error) {
        alert('提交失败，请稍后再试');
      }
    });
  }

  const reminderList = document.querySelector('#reminder-list');
  if (reminderList) {
    reminderList.addEventListener('click', async (event) => {
      const button = event.target.closest('button.reminder-action');
      if (!button) return;
      const id = button.dataset.id;
      await apiFetch(`/api/reminders/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ completed: true }),
      });
      await loadDashboard();
    });
  }
}

function toggleModal(id, visible) {
  const modal = document.getElementById(id);
  if (!modal) return;
  modal.classList.toggle('hidden', !visible);
}

// ======== Auth helpers & UI toggling ========
function readCurrentUser() {
  try {
    const raw = localStorage.getItem('currentUser');
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function saveCurrentUser(user) {
  state.currentUser = user;
  state.dashboard = null;
  state.doctorDashboard = null;
  state.activePetId = null;
  try {
    localStorage.setItem('currentUser', JSON.stringify(user));
  } catch {}
}

function clearCurrentUser() {
  state.currentUser = null;
  state.dashboard = null;
  state.doctorDashboard = null;
  state.activePetId = null;
  state.selectedConsultationId = null;
  state.selectedPatientId = null;
  try {
    localStorage.removeItem('currentUser');
  } catch {}
}

function updateAuthUI() {
  const loginView = document.getElementById('login-view');
  const appHeader = document.getElementById('app-header');
  const userMain = document.getElementById('app-main');
  const doctorMain = document.getElementById('doctor-main');
  const titleEl = document.getElementById('app-title');
  const subtitleEl = document.getElementById('app-subtitle');
  const headerRoleEl = document.getElementById('header-role');
  const authed = !!(state.currentUser && state.currentUser.id);
  if (loginView) loginView.classList.toggle('hidden', authed);
  if (appHeader) appHeader.classList.toggle('hidden', !authed);
  const isDoctor = state.currentUser?.role === 'doctor';
  if (userMain) userMain.classList.toggle('hidden', !authed || isDoctor);
  if (doctorMain) doctorMain.classList.toggle('hidden', !authed || !isDoctor);
  if (titleEl && subtitleEl) {
    if (isDoctor) {
      titleEl.textContent = '医生工作台';
      subtitleEl.textContent = '查看用户咨询 · 追踪宠物健康状态';
    } else {
      titleEl.textContent = '宠物健康管理面板';
      subtitleEl.textContent = '记录健康数据 · 管理医疗档案 · 智能预警提醒';
    }
  }
  if (headerRoleEl) {
    headerRoleEl.textContent = isDoctor ? '医生' : '用户';
  }
}

async function handleLogin(email, password, role) {
  // role is now passed directly from the form

  const payload = { email, password };
  if (role) payload.role = role;

  const res = await apiFetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || '登录失败');
  }
  const user = await res.json();
  // if backend didn't include role, fall back to selected role
  if ((!user.role || user.role === '') && role) {
    user.role = role;
  }
  saveCurrentUser(user);
}

function bindAuthEvents() {
  const loginForm = document.getElementById('login-form');
  const loginError = document.getElementById('login-error');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (loginError) {
        loginError.textContent = '';
        loginError.classList.add('hidden');
      }
      const form = new FormData(loginForm);
      const email = form.get('email');
      const password = form.get('password');
      const role = form.get('role');
      try {
        await handleLogin(email, password, role);
        updateAuthUI();
        if (state.currentUser?.role === 'doctor') {
          await loadDoctorDashboard();
        } else {
          await loadDashboard();
        }
      } catch (err) {
        if (loginError) {
          loginError.textContent = err.message || '登录失败';
          loginError.classList.remove('hidden');
        }
      }
    });
  }

  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      clearCurrentUser();
      updateAuthUI();
    });
  }
}

function bindDoctorEvents() {
  const consultContainer = document.querySelector('#doctor-consultations');
  if (consultContainer) {
    consultContainer.addEventListener('click', (event) => {
      const button = event.target.closest('button[data-action]');
      if (!button) return;
      const action = button.dataset.action;
      if (action === 'respond') {
        const id = button.dataset.id;
        state.selectedConsultationId = id;
        populateConsultResponseModal(id);
        toggleModal('consult-response-modal', true);
      } else if (action === 'view-patient') {
        const userId = button.dataset.userId;
        if (userId) {
          showPatientDetail(userId);
        }
      }
    });
  }

  const patientContainer = document.querySelector('#doctor-patients');
  if (patientContainer) {
    patientContainer.addEventListener('click', (event) => {
      const button = event.target.closest('button[data-action="view-detail"]');
      if (!button) return;
      const userId = button.dataset.userId;
      if (userId) {
        showPatientDetail(userId);
      }
    });
  }

  const responseForm = document.getElementById('consult-response-form');
  if (responseForm) {
    responseForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (!state.selectedConsultationId) return;
      const formData = new FormData(responseForm);
      const payload = {
        status: formData.get('status'),
        doctorNotes: formData.get('doctorNotes'),
        prescription: formData.get('prescriptionItems')
          ? {
              items: formData
                .get('prescriptionItems')
                .split('\n')
                .map((line) => line.trim())
                .filter(Boolean)
                .map((item) => ({ description: item })),
              notes: formData.get('prescriptionNotes') || '',
            }
          : null,
      };
      if (!payload.prescription) {
        delete payload.prescription;
      }
      try {
        await apiFetch(`/api/consultations/${state.selectedConsultationId}/respond`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        toggleModal('consult-response-modal', false);
        responseForm.reset();
        state.selectedConsultationId = null;
        await loadDoctorDashboard();
      } catch (error) {
        alert('回复失败，请稍后再试');
      }
    });
  }
}

window.addEventListener('DOMContentLoaded', async () => {
  // bind general UI events
  bindUserEvents();
  bindDoctorEvents();
  // bind auth-specific events
  bindAuthEvents();
  // restore user and show proper view
  state.currentUser = readCurrentUser();
  updateAuthUI();
  // if logged in, load dashboard
  if (state.currentUser) {
    try {
      if (state.currentUser.role === 'doctor') {
        await loadDoctorDashboard();
      } else {
        await loadDashboard();
      }
    } catch (error) {
      console.error(error);
      // if failed, likely session invalid; reset to login
      clearCurrentUser();
      updateAuthUI();
    }
  }
});
