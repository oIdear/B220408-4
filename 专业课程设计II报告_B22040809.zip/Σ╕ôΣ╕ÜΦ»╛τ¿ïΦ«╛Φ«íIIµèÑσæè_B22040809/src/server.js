const http = require('http');
const fs = require('fs');
const path = require('path');
const { readStore, writeStore, generateId } = require('./storage');

const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
};

function sendJson(res, status, payload) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,PATCH,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  });
  res.end(JSON.stringify(payload));
}

function sendText(res, status, content, contentType = 'text/plain; charset=utf-8') {
  res.writeHead(status, {
    'Content-Type': contentType,
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,PATCH,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  });
  res.end(content);
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (chunk) => chunks.push(chunk));
    req.on('end', () => {
      if (!chunks.length) {
        resolve({});
        return;
      }
      try {
        const raw = Buffer.concat(chunks).toString();
        resolve(JSON.parse(raw));
      } catch (error) {
        reject(error);
      }
    });
    req.on('error', reject);
  });
}

function getWeightSeries(store, petId) {
  return store.healthLogs
    .filter((log) => log.petId === petId)
    .sort((a, b) => new Date(a.date) - new Date(b.date))
    .map((log) => ({ date: log.date, weight: log.weight }));
}

function buildDashboard(store, userId) {
  const user = store.users.find((u) => u.id === userId);
  if (!user) {
    return null;
  }

  const pets = store.pets
    .filter((pet) => pet.ownerId === userId)
    .map((pet) => ({
      ...pet,
      weightSeries: getWeightSeries(store, pet.id),
    }));

  const petMap = new Map(pets.map((pet) => [pet.id, pet]));

  const remindersWithPet = store.reminders
    .filter((reminder) => petMap.has(reminder.petId))
    .map((reminder) => ({
      ...reminder,
      pet: petMap.get(reminder.petId) || null,
    }));

  const alertsWithPet = store.alerts
    .filter((alert) => petMap.has(alert.petId))
    .map((alert) => ({
      ...alert,
      pet: petMap.get(alert.petId) || null,
    }));

  const consultations = store.consultations
    .filter((consult) => consult.userId === userId)
    .map((consult) => ({
      ...consult,
      pet: petMap.get(consult.petId) || null,
      user,
      doctor: store.users.find((u) => u.id === consult.doctorId) || null,
    }));

  const doctors = store.users.filter((u) => u.role === 'doctor');
  const healthLogs = store.healthLogs.filter((log) => petMap.has(log.petId));

  return {
    currentUser: {
      id: user.id,
      name: user.name,
      role: user.role,
      email: user.email,
    },
    pets,
    healthLogs,
    reminders: remindersWithPet,
    alerts: alertsWithPet,
    consultations,
    doctors,
  };
}

function getLatestHealthStatus(store, petId) {
  const logs = store.healthLogs
    .filter((log) => log.petId === petId)
    .sort((a, b) => new Date(b.date) - new Date(a.date));
  if (!logs.length) {
    return null;
  }
  const latest = logs[0];
  return {
    date: latest.date,
    weight: latest.weight,
    diet: latest.diet,
    exercise: latest.exercise,
  };
}

function buildDoctorDashboard(store, doctorId) {
  const doctor = store.users.find((u) => u.id === doctorId && u.role === 'doctor');
  if (!doctor) {
    return null;
  }

  const consultations = store.consultations
    .filter((consult) => consult.doctorId === doctorId)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map((consult) => {
      const user = store.users.find((u) => u.id === consult.userId) || null;
      const pet = store.pets.find((p) => p.id === consult.petId) || null;
      const alerts = pet ? store.alerts.filter((alert) => alert.petId === pet.id) : [];
      return {
        ...consult,
        user: user
          ? {
              id: user.id,
              name: user.name,
              email: user.email,
            }
          : null,
        pet: pet
          ? {
              ...pet,
              weightSeries: getWeightSeries(store, pet.id),
              latestHealth: getLatestHealthStatus(store, pet.id),
              alerts,
            }
          : null,
      };
    });

  const patientMap = new Map();
  consultations.forEach((consult) => {
    if (consult.user) {
      patientMap.set(consult.user.id, consult.user);
    }
  });

  const patients = Array.from(patientMap.values()).map((patient) => {
    const pets = store.pets
      .filter((pet) => pet.ownerId === patient.id)
      .map((pet) => ({
        ...pet,
        weightSeries: getWeightSeries(store, pet.id),
        latestHealth: getLatestHealthStatus(store, pet.id),
        alerts: store.alerts.filter((alert) => alert.petId === pet.id),
      }));
    return {
      ...patient,
      pets,
    };
  });

  return {
    doctor: {
      id: doctor.id,
      name: doctor.name,
      email: doctor.email,
      role: doctor.role,
      specialty: doctor.specialty || null,
    },
    consultations,
    patients,
  };
}

async function handleApi(req, res, url) {
  if (req.method === 'OPTIONS') {
    sendText(res, 204, '');
    return true;
  }

  const store = readStore();

  if (req.method === 'POST' && url.pathname === '/api/login') {
    try {
      const body = await parseBody(req);
      const { email, password, role } = body;
      if (!email || !password) {
        sendJson(res, 400, { error: '缺少邮箱或密码' });
        return true;
      }
      // 使用 role 进行精确匹配（如果提供了 role），否则接受任何角色
      const user = store.users.find((u) => 
        u.email === email && 
        u.password === password && 
        (role ? u.role === role : (u.role === 'user' || u.role === 'doctor')));
      if (!user) {
        sendJson(res, 401, { error: '邮箱或密码不正确' });
        return true;
      }
      sendJson(res, 200, {
        id: user.id,
        name: user.name,
        role: user.role,
        email: user.email,
        specialty: user.specialty || null,
      });
    } catch (error) {
      sendJson(res, 400, { error: '请求格式错误', details: error.message });
    }
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/api/dashboard') {
    const userId = url.searchParams.get('userId');
    if (!userId) {
      sendJson(res, 401, { error: '未提供用户信息' });
      return true;
    }
    const dashboard = buildDashboard(store, userId);
    if (!dashboard) {
      sendJson(res, 404, { error: '用户不存在' });
      return true;
    }
    sendJson(res, 200, dashboard);
    return true;
  }

  if (req.method === 'GET' && url.pathname === '/api/doctor-dashboard') {
    const doctorId = url.searchParams.get('doctorId');
    if (!doctorId) {
      sendJson(res, 401, { error: '未提供医生信息' });
      return true;
    }
    const dashboard = buildDoctorDashboard(store, doctorId);
    if (!dashboard) {
      sendJson(res, 404, { error: '医生不存在' });
      return true;
    }
    sendJson(res, 200, dashboard);
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/pets') {
    try {
      const body = await parseBody(req);
      const petId = generateId('pet');
      const newPet = {
        id: petId,
        ownerId: body.ownerId,
        name: body.name,
        species: body.species,
        breed: body.breed,
        age: body.age,
        vaccinations: body.vaccinations || [],
        medicalRecords: [],
      };
      store.pets.push(newPet);
      const owner = store.users.find((u) => u.id === body.ownerId);
      if (owner) {
        owner.pets = owner.pets || [];
        owner.pets.push(petId);
      }
      writeStore(store);
      sendJson(res, 201, newPet);
    } catch (error) {
      sendJson(res, 400, { error: 'Invalid payload', details: error.message });
    }
    return true;
  }

  const petLogMatch = url.pathname.match(/^\/api\/pets\/([^/]+)\/logs$/);
  if (petLogMatch && req.method === 'POST') {
    try {
      const body = await parseBody(req);
      const petId = petLogMatch[1];
      const pet = store.pets.find((p) => p.id === petId);
      if (!pet) {
        sendJson(res, 404, { error: 'Pet not found' });
        return true;
      }
      const log = {
        id: generateId('log'),
        petId,
        date: body.date,
        weight: body.weight,
        diet: body.diet,
        exercise: body.exercise,
      };
      store.healthLogs.push(log);
      // simple alert rule: weight drop > 0.3 compared to last log
      const series = getWeightSeries(store, petId);
      if (series.length >= 2) {
        const lastTwo = series.slice(-2);
        const delta = lastTwo[1].weight - lastTwo[0].weight;
        if (delta <= -0.3) {
          store.alerts.push({
            id: generateId('alert'),
            petId,
            type: 'weight_drop',
            message: `${pet.name} 最近体重下降 ${Math.abs(delta).toFixed(1)}kg，请关注饮食与行为。`,
            createdAt: new Date().toISOString(),
            resolved: false,
          });
        }
      }
      writeStore(store);
      sendJson(res, 201, log);
    } catch (error) {
      sendJson(res, 400, { error: 'Invalid payload', details: error.message });
    }
    return true;
  }

  if (req.method === 'PATCH' && url.pathname.startsWith('/api/reminders/')) {
    const reminderId = url.pathname.split('/').pop();
    const reminder = store.reminders.find((r) => r.id === reminderId);
    if (!reminder) {
      sendJson(res, 404, { error: 'Reminder not found' });
      return true;
    }
    try {
      const body = await parseBody(req);
      if (typeof body.completed === 'boolean') {
        reminder.completed = body.completed;
      }
      if (body.dueDate) {
        reminder.dueDate = body.dueDate;
      }
      writeStore(store);
      sendJson(res, 200, reminder);
    } catch (error) {
      sendJson(res, 400, { error: 'Invalid payload', details: error.message });
    }
    return true;
  }

  if (req.method === 'POST' && url.pathname === '/api/consultations') {
    try {
      const body = await parseBody(req);
      const consult = {
        id: generateId('consult'),
        petId: body.petId,
        userId: body.userId,
        doctorId: body.doctorId,
        status: 'in_review',
        question: body.question,
        doctorNotes: null,
        prescriptionId: null,
        createdAt: new Date().toISOString(),
      };
      store.consultations.push(consult);
      writeStore(store);
      sendJson(res, 201, consult);
    } catch (error) {
      sendJson(res, 400, { error: 'Invalid payload', details: error.message });
    }
    return true;
  }

  const consultationResponseMatch = url.pathname.match(/^\/api\/consultations\/([^/]+)\/respond$/);
  if (consultationResponseMatch && req.method === 'POST') {
    try {
      const consultId = consultationResponseMatch[1];
      const consultation = store.consultations.find((c) => c.id === consultId);
      if (!consultation) {
        sendJson(res, 404, { error: 'Consultation not found' });
        return true;
      }
      const body = await parseBody(req);
      consultation.status = body.status || 'answered';
      consultation.doctorNotes = body.doctorNotes || '';
      if (body.prescription) {
        const prescription = {
          id: generateId('rx'),
          consultationId: consultId,
          petId: consultation.petId,
          doctorId: consultation.doctorId,
          issuedAt: new Date().toISOString(),
          status: 'pending_review',
          items: body.prescription.items || [],
          notes: body.prescription.notes || '',
        };
        consultation.prescriptionId = prescription.id;
        store.prescriptions.push(prescription);
      }
      writeStore(store);
      sendJson(res, 200, consultation);
    } catch (error) {
      sendJson(res, 400, { error: 'Invalid payload', details: error.message });
    }
    return true;
  }

  return false;
}

function handleStatic(req, res, url) {
  let filePath = path.join(PUBLIC_DIR, url.pathname === '/' ? 'index.html' : url.pathname);
  if (!filePath.startsWith(PUBLIC_DIR)) {
    sendText(res, 403, 'Forbidden');
    return;
  }
  fs.stat(filePath, (err, stat) => {
    if (err) {
      if (url.pathname === '/' || !path.extname(url.pathname)) {
        // SPA fallback
        const fallback = path.join(PUBLIC_DIR, 'index.html');
        fs.readFile(fallback, (fallbackErr, content) => {
          if (fallbackErr) {
            sendText(res, 404, 'Not found');
          } else {
            sendText(res, 200, content, MIME_TYPES['.html']);
          }
        });
      } else {
        sendText(res, 404, 'Not found');
      }
      return;
    }
    if (stat.isDirectory()) {
      filePath = path.join(filePath, 'index.html');
    }
    fs.readFile(filePath, (readErr, content) => {
      if (readErr) {
        sendText(res, 500, 'Server error');
        return;
      }
      const ext = path.extname(filePath);
      const mime = MIME_TYPES[ext] || 'application/octet-stream';
      sendText(res, 200, content, mime);
    });
  });
}

function startServer(port = 8000) {
  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, `http://${req.headers.host}`);
    try {
      const handled = await handleApi(req, res, url);
      if (!handled) {
        handleStatic(req, res, url);
      }
    } catch (error) {
      console.error('Server error:', error);
      sendJson(res, 500, { error: 'Internal server error' });
    }
  });
  server.listen(port, () => {
    console.log(`Server listening on http://localhost:${port}`);
  });
}

if (require.main === module) {
  const port = process.env.PORT ? Number(process.env.PORT) : 3000;
  startServer(port);
}

module.exports = { startServer };
